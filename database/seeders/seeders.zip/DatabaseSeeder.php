<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            BloodTypesSeeder::class,
            BloodBanksSeeder::class,
            DiagnosticCentersSeeder::class,
            BloodRequestsSeeder::class,
            DonorsSeeder::class,
            DonationsSeeder::class,
            DonationRequestsSeeder::class,
            NidVerificationsSeeder::class,
            BloodNotificationsSeeder::class,
            DonorCareSeeder::class,
            PostsSeeder::class,
        ]);
    }
}
